-- Migration Agent SQL Backup
-- Source: aws-1-us-west-2.pooler.supabase.com/postgres
-- trace_id: bfcf341c-c279-45ba-9686-bfd5b7a44433
-- Generated: 2026-06-04T18:01:37.780613+00:00
-- Restore: psql <target_url> < bfcf341c-c279-45ba-9686-bfd5b7a44433.sql

-- Table abase_legacy_users: 0 rows
-- Table: experiments (24 rows)
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (5, 2, 'PLT-2001', 'B04', 62.0, '2023-01-15 08:35:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-55ADDE', 10.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (6, 2, 'PLT-2001', 'B03', 63.0, '2023-01-15 08:30:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-BE8130', 10.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (7, 2, 'PLT-2001', 'B02', 7.65, '2023-01-15 08:25:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-FA18FB', 10.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (8, 2, 'PLT-2001', 'B01', 9.1, '2023-01-15 08:20:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-D17EBC', 10.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (13, 4, 'PLT-2002', 'B04', 65.9, '2023-02-10 09:35:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-CC31F2', 10.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (14, 4, 'PLT-2002', 'B03', 14.67, '2023-02-10 09:30:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-8097D5', 10.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (15, 4, 'PLT-2002', 'B02', 7.23, '2023-02-10 09:25:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-EEB941', 10.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (16, 4, 'PLT-2002', 'B01', 12.45, '2023-02-10 09:20:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-26FB9C', 10.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (25, 7, 'PLT-2004', 'A04', 8.88, '2023-04-12 11:15:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-8BF5F2', 10.0, 'Cytotoxicity');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (26, 7, 'PLT-2004', 'A03', 10.44, '2023-04-12 11:10:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-C15324', 10.0, 'Cytotoxicity');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (27, 7, 'PLT-2004', 'A02', 63.0, '2023-04-12 11:05:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-4819A8', 10.0, 'Cytotoxicity');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (28, 7, 'PLT-2004', 'A01', 5.91, '2023-04-12 11:00:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-7BA2FB', 10.0, 'Cytotoxicity');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (45, 12, 'PLT-2006', 'B04', 10.56, '2023-06-14 09:35:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-984A37', 1.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (46, 12, 'PLT-2006', 'B03', 71.3, '2023-06-14 09:30:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-FC0C7E', 1.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (47, 12, 'PLT-2006', 'B02', 12.34, '2023-06-14 09:25:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-10D56A', 1.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (48, 12, 'PLT-2006', 'B01', 8.9, '2023-06-14 09:20:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-25226F', 1.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (69, 18, 'PLT-2009', 'B04', 66.0, '2023-09-22 08:35:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-443D75', 30.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (70, 18, 'PLT-2009', 'B03', 68.4, '2023-09-22 08:30:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-3514F3', 30.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (71, 18, 'PLT-2009', 'B02', 7.89, '2023-09-22 08:25:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-B23288', 30.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (72, 18, 'PLT-2009', 'B01', 13.45, '2023-09-22 08:20:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-DA8B73', 30.0, 'Functional');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (77, 20, 'PLT-2010', 'B04', 74.8, '2023-10-18 09:35:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-D61C0B', 30.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (78, 20, 'PLT-2010', 'B03', 9.34, '2023-10-18 09:30:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-943D7C', 30.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (79, 20, 'PLT-2010', 'B02', 10.56, '2023-10-18 09:25:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-94BA80', 30.0, 'Cell-based');
INSERT INTO "experiments" ("id", "user_id", "plate_barcode", "well_position", "raw_value", "recorded_at", "created_at", "migrated_at", "compound_id", "concentration_um", "assay_type") VALUES (80, 20, 'PLT-2010', 'B01', 7.23, '2023-10-18 09:20:00+00:00', '2026-06-04 16:58:08.519743+00:00', NULL, 'CMP-08B8EF', 30.0, 'Cell-based');

-- Table gds_experiments: 0 rows
-- Table: gds_staging_experiments (16 rows)
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (375, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'A01', 14.52, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Smith_J', 'Biochemistry');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (376, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'A02', 8.73, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Chen_L', 'Molecular Biology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (377, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'B01', 12.18, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Patel_R', 'Pharmacology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (378, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'B02', 3.45, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Smith_J', 'Biochemistry');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (379, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'C01', 9.87, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Williams_K', 'Immunology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (380, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'C02', 11.22, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Rodriguez_M', 'Genetics');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (381, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'D01', 0.95, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Kim_S', 'Biochemistry');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (382, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'D02', 15.01, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Mueller_T', 'Pharmacology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (383, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'E01', 7.64, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Okonkwo_A', 'Immunology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (384, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'E02', 12.33, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Smith_J', 'Biochemistry');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (385, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'F01', 6.55, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Chen_L', 'Molecular Biology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (386, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'F02', 10.89, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Patel_R', 'Pharmacology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (387, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'G01', 8.12, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Williams_K', 'Immunology');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (388, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'G02', 9.44, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Rodriguez_M', 'Genetics');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (389, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'H01', 13.21, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Kim_S', 'Biochemistry');
INSERT INTO "gds_staging_experiments" ("staging_id", "trace_id", "well_position", "signal", "status", "created_at", "scientist_name", "scientist_role") VALUES (390, '89be3b58-9c46-4837-82d0-128c3c21da5d', 'H02', 11.77, 'pending', '2026-05-30 19:09:01.849329+00:00', 'Mueller_T', 'Pharmacology');

-- Table: gds_users (1 rows)
INSERT INTO "gds_users" ("gds_user_id", "name", "role") VALUES ('ee0d9029-c12f-49f9-9ab8-6d42f3a3ba0f', 'Admin User', 'admin');

-- Table: migration_audit_log (3 rows)
INSERT INTO "migration_audit_log" ("id", "trace_id", "error_detail", "created_at") VALUES (1, '7c4f11b4-fdaf-4b9b-902d-e99714c02ca9', 'Traceback (most recent call last):
  File "/Users/shishirbiwalkar/Migration Agent/backend/app/workers/ai_cleaner.py", line 102, in run_etl
    exec(cleaning_script, namespace)  # noqa: S102
    ~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "<string>", line 1, in <module>
    from multiprocessing.spawn import spawn_main; spawn_main(tracker_fd=5, pipe_handle=7)
ValueError: UNMAPPABLE: this CSV does not contain recognisable well_position or signal columns.
', '2026-05-30 06:27:38.207269+00:00');
INSERT INTO "migration_audit_log" ("id", "trace_id", "error_detail", "created_at") VALUES (2, 'c473198c-2403-4b98-86d5-cb7074fa0a49', 'Traceback (most recent call last):
  File "/Users/shishirbiwalkar/Migration Agent/backend/app/workers/ai_cleaner.py", line 102, in run_etl
    exec(cleaning_script, namespace)  # noqa: S102
    ~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "<string>", line 1, in <module>
    from multiprocessing.spawn import spawn_main; spawn_main(tracker_fd=5, pipe_handle=7)
ValueError: UNMAPPABLE: this CSV does not contain recognisable well_position or signal columns.
', '2026-05-30 06:40:46.848512+00:00');
INSERT INTO "migration_audit_log" ("id", "trace_id", "error_detail", "created_at") VALUES (3, '7d8fc9cf-8525-4cec-ac39-3186a24037cf', 'Traceback (most recent call last):
  File "/Users/shishirbiwalkar/Migration Agent/backend/app/workers/ai_cleaner.py", line 114, in run_etl
    exec(cleaning_script, namespace)  # noqa: S102
    ~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "<string>", line 27, in <module>
ValueError: UNMAPPABLE: CSV does not contain recognisable scientific experiment data with scientist and signal columns.
', '2026-05-30 19:08:57.485519+00:00');

-- Table: users (6 rows)
INSERT INTO "users" ("id", "name", "department", "email", "last_login", "active_time_minutes", "created_at", "migrated_at") VALUES (2, 'Chen_L', 'Molecular Biology', 'chen.l@lab.internal', '2024-01-19 14:30:00+00:00', 2103, '2026-06-04 16:58:08.453277+00:00', NULL);
INSERT INTO "users" ("id", "name", "department", "email", "last_login", "active_time_minutes", "created_at", "migrated_at") VALUES (4, 'Williams_K', 'Immunology', 'williams.k@lab.internal', '2024-01-17 16:45:00+00:00', 987, '2026-06-04 16:58:08.453277+00:00', NULL);
INSERT INTO "users" ("id", "name", "department", "email", "last_login", "active_time_minutes", "created_at", "migrated_at") VALUES (7, 'Mueller_T', 'Toxicology', 'mueller.t@lab.internal', '2024-01-16 10:30:00+00:00', 1123, '2026-06-04 16:58:08.453277+00:00', NULL);
INSERT INTO "users" ("id", "name", "department", "email", "last_login", "active_time_minutes", "created_at", "migrated_at") VALUES (12, 'Lee_H', 'Immunology', 'lee.h@lab.internal', '2024-01-19 10:15:00+00:00', 3102, '2026-06-04 16:58:08.453277+00:00', NULL);
INSERT INTO "users" ("id", "name", "department", "email", "last_login", "active_time_minutes", "created_at", "migrated_at") VALUES (18, 'Singh_A', 'Molecular Biology', 'singh.a@lab.internal', '2024-01-21 14:30:00+00:00', 1432, '2026-06-04 16:58:08.453277+00:00', NULL);
INSERT INTO "users" ("id", "name", "department", "email", "last_login", "active_time_minutes", "created_at", "migrated_at") VALUES (20, 'Walsh_D', 'Immunology', 'walsh.d@lab.internal', '2024-01-19 16:00:00+00:00', 1789, '2026-06-04 16:58:08.453277+00:00', NULL);
